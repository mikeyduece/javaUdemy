package com.company;

import java.lang.reflect.InvocationTargetException;

public interface FilingWorkflow {
    void buildReturn(String klassName);
}
