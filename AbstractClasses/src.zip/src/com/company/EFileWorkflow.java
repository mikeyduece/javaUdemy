package com.company;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;

public class EFileWorkflow implements FilingWorkflow {

    @Override
    public void buildReturn(String klassName) {
        System.out.println(klassName + " Instance of build return called");
    }

    public static void buildReturnFiles(HashMap<String, String> klassName) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        String state = klassName.get("state");
        Class<?> classRef = Class.forName("com.company.States." + state);
        Method buildReturn = classRef.getMethod("buildReturn", String.class);
        Object instance = classRef.getDeclaredConstructor().newInstance();
        buildReturn.invoke(instance, state);
    }

}
