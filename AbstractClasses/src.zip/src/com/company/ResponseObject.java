package com.company;

public class ResponseObject {
    private String state;

    public ResponseObject(String state) {
        this.state = state;
    }

    public String getState() {
        return state;
    }
}
